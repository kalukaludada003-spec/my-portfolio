# Kamal Bastola — Personal Portfolio

## Files
- `index.html` — website structure
- `style.css` — responsive styling
- `script.js` — greeting, age/days calculation, navigation, and contact-form validation

## Run locally
Open this folder in VS Code. You can open `index.html` in a browser, or use the Live Server extension.

## Lab JavaScript console task
When the page loads, answer the two prompts (name and birth year). Open Chrome Developer Tools with `F12`, select **Console**, and you should see:
- A time-based greeting
- Approximate age and days lived
- Adult/minor verification

The days calculation is approximate (365 days per year), as requested in the lab.

## Contact form note
The form currently checks that the fields are valid and displays a confirmation on the page. It does not email or store messages. To receive submissions, connect it to a form service or a server-side endpoint.

## GitHub submission
After taking your own screenshot of the Chrome Console and saving it in this folder as `screenshot.png`, run:

```bash
git init
git add index.html style.css script.js README.md screenshot.png
git commit -m "Create Kamal Bastola portfolio"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your actual GitHub repository URL. Get the commit hash with `git rev-parse HEAD`.
