// Part 1: Time-based greeting
// Ask for the visitor's name and display a personalized greeting in the console.
const visitorNameInput = prompt("Hello! What is your name?");
const visitorName = visitorNameInput && visitorNameInput.trim()
  ? visitorNameInput.trim()
  : "there";

const currentHour = new Date().getHours();
let greeting;

if (currentHour < 12) {
  greeting = "Good morning";
} else if (currentHour < 18) {
  greeting = "Good afternoon";
} else {
  greeting = "Good evening";
}

console.log(`${greeting}, ${visitorName}!`);

// Part 2: Age and approximate days lived
const birthYearInput = prompt("What year were you born? (Example: 2005)");
const birthYear = Number(birthYearInput);
const currentYear = new Date().getFullYear();

if (
  birthYearInput !== null &&
  birthYearInput.trim() !== "" &&
  Number.isInteger(birthYear) &&
  birthYear >= 1900 &&
  birthYear <= currentYear
) {
  const age = currentYear - birthYear;
  const daysLived = age * 365;

  console.log(`You are approximately ${age} years old.`);
  console.log(`You have lived for approximately ${daysLived} days!`);

  if (age >= 18) {
    console.log("You are an adult.");
  } else {
    console.log("You are a minor.");
  }
} else {
  console.log("Birth year was not valid, so age could not be calculated.");
}

// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

// Contact form: front-end validation only.
// To receive messages, connect this form to a service or your own backend.
const contactForm = document.getElementById("contactForm");
const formFeedback = document.getElementById("formFeedback");

contactForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!contactForm.checkValidity()) {
    contactForm.reportValidity();
    return;
  }

  const senderName = document.getElementById("name").value.trim();
  formFeedback.textContent =
    `Thanks, ${senderName}! Your form is valid. This demo does not send or store messages yet.`;
  contactForm.reset();
});
